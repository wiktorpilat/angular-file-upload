import { Component, OnInit } from '@angular/core';
import { UploadService } from '../upload.service'

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {

  files: any = [];

  constructor(private uploadService:UploadService) { }

  ngOnInit(): void {
  }

  uploadFile(event:any) {
    console.log("   +++   upload component - upload file");
    console.log(event);
    const fileList = Array.from(event);
    for (let index = 0; index < fileList.length; index++) {
      const element = fileList[index] as File;
      this.files.push(element.name)
      this.uploadService.uploadFile(element);
    }  
  }

  uploadFiles(event:any) {
    console.log("   +++   upload component - upload files");
    console.log(event);
    const fileList = Array.from(event);
    for (let index = 0; index < fileList.length; index++) {
      const element = fileList[index] as File;
      this.files.push(element.name)
      this.uploadService.uploadFile(element);
    }  
  }
  
  deleteAttachment(index:number) {
    this.files.splice(index, 1)
  }
}